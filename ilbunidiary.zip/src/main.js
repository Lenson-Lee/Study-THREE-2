import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader";
import * as CANNON from "cannon-es";
import { Player } from "./Player";
import { Piano } from "./Piano";
import { Coin } from "./Coin";
import { Loader } from "./Loader";
import { CarSpot, PianoSpot, CoinSpot } from "./SpotMesh";
// import { Sound } from "./Sound";
import gsap from "gsap";
import { AmbientLightProbe } from "three";

// Texture
const textureLoader = new THREE.TextureLoader();
const floorTexture = textureLoader.load("/images/grid.png");
floorTexture.wrapS = THREE.RepeatWrapping;
floorTexture.wrapT = THREE.RepeatWrapping;
floorTexture.repeat.x = 10;
floorTexture.repeat.y = 10;

// Renderer
const canvas = document.querySelector("#three-canvas");
const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: true,
});

renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio > 1 ? 2 : 1);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

// Scene
const scene = new THREE.Scene();
const gltfLoader = new GLTFLoader();

//그리드
const axesHelper = new THREE.AxesHelper(100);
const grid = new THREE.GridHelper(100, 100);
// scene.add(grid, axesHelper);

// Camera
const camera = new THREE.OrthographicCamera(
  -(window.innerWidth / window.innerHeight), // left
  window.innerWidth / window.innerHeight, // right,
  1, // top
  -1, // bottom
  -1000,
  1000
);

const cameraPosition = new THREE.Vector3(1, 4, 5);
camera.position.set(cameraPosition.x, cameraPosition.y, cameraPosition.z);
camera.zoom = 0.2;
camera.updateProjectionMatrix();
scene.add(camera);

// Light
const ambientLight = new THREE.AmbientLight("white", 0.7);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight("white", 0.5);
const directionalLightOriginPosition = new THREE.Vector3(1, 1, 1);
directionalLight.position.x = directionalLightOriginPosition.x;
directionalLight.position.y = directionalLightOriginPosition.y;
directionalLight.position.z = directionalLightOriginPosition.z;
directionalLight.castShadow = true;

// mapSize 세팅으로 그림자 퀄리티 설정
directionalLight.shadow.mapSize.width = 2048;
directionalLight.shadow.mapSize.height = 2048;
// 그림자 범위
directionalLight.shadow.camera.left = -100;
directionalLight.shadow.camera.right = 100;
directionalLight.shadow.camera.top = 100;
directionalLight.shadow.camera.bottom = -100;
directionalLight.shadow.camera.near = -100;
directionalLight.shadow.camera.far = 100;
scene.add(directionalLight);

// Mesh
const meshes = [];

/* 바닥 격자무늬 */
const floorMesh = new THREE.Mesh(
  new THREE.PlaneGeometry(100, 100),
  new THREE.MeshStandardMaterial({
    map: floorTexture,
  })
);
floorMesh.name = "floor";
floorMesh.rotation.x = -Math.PI / 2;
floorMesh.receiveShadow = true;
scene.add(floorMesh);
meshes.push(floorMesh);

/* 마우스 클릭 포인터 */
const pointerMesh = new THREE.Mesh(
  new THREE.PlaneGeometry(1, 1),
  new THREE.MeshBasicMaterial({
    color: "crimson",
    transparent: true,
    opacity: 0.5,
  })
);
pointerMesh.rotation.x = -Math.PI / 2;
pointerMesh.position.y = 0.01;
pointerMesh.receiveShadow = true;
scene.add(pointerMesh);

/* 이벤트 스팟 포인터 ____________________________________________*/
const car_spotMesh = CarSpot;
const piano_spotMesh = PianoSpot;
const coin_spotMesh = CoinSpot;

scene.add(CarSpot, piano_spotMesh, coin_spotMesh);
//

// Cannon(물리 엔진) + 성능을 위한 세팅
const cannonWorld = new CANNON.World();
cannonWorld.gravity.set(0, -20, 0);
// cannonWorld.allowSleep = true;
cannonWorld.broadphase = new CANNON.SAPBroadphase(cannonWorld);

// Contact Material
const defaultMaterial = new CANNON.Material("default");
const defaultContactMaterial = new CANNON.ContactMaterial(
  defaultMaterial,
  defaultMaterial,
  {
    friction: 0.5,
    restitution: 0.3,
  }
);
cannonWorld.defaultContactMaterial = defaultContactMaterial;

const floorShape = new CANNON.Plane();
const floorBody = new CANNON.Body({
  mass: 0,
  position: new CANNON.Vec3(0, 0, 0),
  shape: floorShape,
  material: defaultMaterial,
});
floorBody.quaternion.setFromAxisAngle(new CANNON.Vec3(-1, 0, 0), Math.PI / 2);
cannonWorld.addBody(floorBody);

//__________________________________________________________________________
/* piano 스팟에 가면 노래 재생 */
// let piano_play = false; // true면 이미 재생중
// function piano_sound(state) {
//   if (piano_play) {
//     return;
//   } else {
//     return Sound("/sounds/whistling.mp3", state);
//   }
// }

const player = new Player({
  scene,
  meshes,
  gltfLoader,
  modelSrc: "/models/ilbuni.glb",
});

/* 박스 배열 */
const boxes = []; //물리 주기위해 배열에 담음
let fallingBlock = false; // 블록을 밀면 추락 이벤트 발생

function coinEvent(state) {
  if (state) {
    let box;
    for (let i = 0; i < 10; i++) {
      box = new Coin({
        index: i,
        scene,
        cannonWorld,
        gltfLoader,
        position: { x: 20 + (i % 2), y: 5 + i * 5, z: 6 + (i % 2) },
      });
      boxes.push(box);
    }
  }
}
//
const moneybox = new Loader({
  scene,
  gltfLoader,
  root: "/models/moneybox/scene.gltf",
  name: "moneybox",
  scale: 0.005,
  position: { x: 18, y: 0, z: 7 },
});

const car = new Loader({
  scene,
  gltfLoader,
  root: "/models/car/scene.gltf",
  name: "car",
  scale: 0.0075,
  position: { x: 0, y: 0, z: -4 },
});
const piano = new Loader({
  scene,
  gltfLoader,
  rotation: { z: Math.PI / 1 },
  root: "/models/piano/scene.gltf",
  name: "piano",
  scale: 5,
  position: { x: 23, y: -1.5, z: 0 },
});
let grasses = [];
const grass_1 = new Loader({
  scene,
  gltfLoader,
  root: "/models/grass/scene.gltf",
  name: "grass",
  scale: 2,
  position: { x: 24, y: -3, z: 2 },
});
const grass_2 = new Loader({
  scene,
  gltfLoader,
  root: "/models/grass/scene.gltf",
  name: "grass",
  scale: 1,
  position: { x: 21.5, y: -3, z: 1.5 },
});
grasses.push(grass_1, grass_2);
// const tree = new Loader({
//   scene,
//   gltfLoader,
//   root: "/models/tree/scene.gltf",
//   name: "grass",
//   scale: 5,
//   position: { x: 20, y: 0, z: 3 },
// });
// const flower = new Loader({
//   scene,
//   gltfLoader,
//   root: "/models/flower/scene.gltf",
//   name: "grass",
//   scale: 0.5,
//   position: { x: 18, y: 0, z: 0 },
// });

const raycaster = new THREE.Raycaster();
let mouse = new THREE.Vector2();
let destinationPoint = new THREE.Vector3();
let angle = 0;
let isPressed = false; // 마우스를 누르고 있는 상태

// 그리기
const clock = new THREE.Clock();

function draw() {
  const delta = clock.getDelta();

  cannonWorld.step(1 / 60, delta, 3);

  if (fallingBlock) {
    boxes.forEach((item) => {
      if (item.cannonBody) {
        item.modelMesh.position.copy(item.cannonBody.position);
        item.modelMesh.quaternion.copy(item.cannonBody.quaternion);
      }
    });
  }

  if (player.mixer) player.mixer.update(delta);

  if (player.modelMesh) {
    camera.lookAt(player.modelMesh.position);
  }

  if (player.modelMesh) {
    if (isPressed) {
      raycasting();
    }

    if (player.moving) {
      // 걸어가는 상태
      angle = Math.atan2(
        destinationPoint.z - player.modelMesh.position.z,
        destinationPoint.x - player.modelMesh.position.x
      );
      player.modelMesh.position.x += Math.cos(angle) * 0.05;
      player.modelMesh.position.z += Math.sin(angle) * 0.05;

      camera.position.x = cameraPosition.x + player.modelMesh.position.x;
      camera.position.z = cameraPosition.z + player.modelMesh.position.z;

      player.actions[0].stop();
      player.actions[1].play();

      /* 목적지와 플레이어 거리를 보고 정지 */
      if (
        Math.abs(destinationPoint.x - player.modelMesh.position.x) < 0.03 &&
        Math.abs(destinationPoint.z - player.modelMesh.position.z) < 0.03
      ) {
        player.moving = false;
        console.log("멈춤");
      }

      /* Car Event */
      if (
        Math.abs(car_spotMesh.position.x - player.modelMesh.position.x) < 1.5 &&
        Math.abs(car_spotMesh.position.z - player.modelMesh.position.z) < 1.5
      ) {
        if (!car.visible) {
          console.log("자동차 탑승해요");

          car.visible = true;
          car_spotMesh.material.color.set("seagreen");

          //플레이어 이동
          player.modelMesh.visible = false;
          gsap.to(player.modelMesh.position, {
            delay: 1,
            duration: 3,
            x: 20,
          });
          gsap.to(car.modelMesh.position, {
            delay: 1,
            duration: 3,
            x: 20,
          });
          gsap.to(camera.position, {
            duration: 1,
            x: 20,
          });

          //이동 후 플레이어 등장 + 자동차 퇴장
          setTimeout(() => {
            player.modelMesh.visible = true;
            gsap.to(car.modelMesh.position, {
              delay: 0.5,
              duration: 3,
              x: 40,
            });
          }, 4000);
        }
      } else if (car.visible) {
        console.log("나갔어요");
        car.visible = false;

        car_spotMesh.material.color.set("yellow");
      }
      /* Piano Event */
      if (
        Math.abs(piano_spotMesh.position.x - player.modelMesh.position.x) <
          1.5 &&
        Math.abs(piano_spotMesh.position.z - player.modelMesh.position.z) < 1.5
      ) {
        if (!piano.visible) {
          console.log("들어왔어요");
          piano.visible = true;

          piano_spotMesh.material.color.set("seagreen");
          gsap.to(piano.modelMesh.position, {
            delay: 1,
            duration: 1,
            y: 0.5,
          });
          grasses.forEach((e, index) => {
            gsap.to(e.modelMesh.position, {
              delay: 1.5 + index / 2,
              duration: 1,
              y: 0,
            });
          });
          gsap.to(camera.position, {
            duration: 1,
            y: 3,
          });
        }
      } else if (piano.visible) {
        console.log("나갔어요");
        piano.visible = false;

        piano_spotMesh.material.color.set("yellow");
        gsap.to(piano.modelMesh.position, {
          duration: 0.5,
          y: -1.5,
        });
        grasses.forEach((e, index) => {
          gsap.to(e.modelMesh.position, {
            delay: 0.5 + index / 5,
            duration: 1,
            y: -3,
          });
        });
        gsap.to(camera.position, {
          duration: 1,
          y: 5,
        });
      }

      /* box spot event */
      if (
        Math.abs(coin_spotMesh.position.x - player.modelMesh.position.x) <
          1.5 &&
        Math.abs(coin_spotMesh.position.z - player.modelMesh.position.z) < 1.5
      ) {
        if (fallingBlock == false) {
          fallingBlock = true;

          coinEvent(true);
          gsap.to(camera.position, {
            duration: 1,
            y: 3,
          });
          gsap.to(moneybox.modelMesh.position, {
            delay: 5,
            duration: 1,
            y: 10,
          });
        }
        coin_spotMesh.material.color.set("seagreen");
      } else {
        coin_spotMesh.material.color.set("yellow");
        // fallingBlock = false;
        gsap.to(camera.position, {
          duration: 1,
          y: 5,
        });
      }
    } else {
      // 서 있는 상태
      player.actions[1].stop();
      player.actions[0].play();
    }
  }

  renderer.render(scene, camera);
  renderer.setAnimationLoop(draw);
}

/* 레이캐스팅때 실행 */
function checkIntersects() {
  // raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObjects(meshes);

  for (const item of intersects) {
    if (item.object.name === "floor") {
      destinationPoint.x = item.point.x;
      destinationPoint.y = 0.3;
      destinationPoint.z = item.point.z;
      //
      player.modelMesh.lookAt(destinationPoint);
      player.moving = true;
      //
      pointerMesh.position.x = destinationPoint.x;
      pointerMesh.position.z = destinationPoint.z;
    }

    if (item.object.cannonBody && fallingBlock) {
      item.object.cannonBody.applyForce(
        new CANNON.Vec3(0, 0, 100),
        new CANNON.Vec3(0, 0, 0)
      );
      break;
    }
    break;
  }
}

function setSize() {
  camera.left = -(window.innerWidth / window.innerHeight);
  camera.right = window.innerWidth / window.innerHeight;
  camera.top = 1;
  camera.bottom = -1;

  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.render(scene, camera);
}

// 이벤트_______________________________________________________
window.addEventListener("resize", setSize);

// 마우스 좌표를 three.js에 맞게 변환
function calculateMousePosition(e) {
  mouse.x = (e.clientX / canvas.clientWidth) * 2 - 1;
  mouse.y = -((e.clientY / canvas.clientHeight) * 2 - 1);
}

// 변환된 마우스 좌표를 이용해 래이캐스팅
function raycasting() {
  raycaster.setFromCamera(mouse, camera);
  checkIntersects();
}

// 마우스 이벤트
canvas.addEventListener("mousedown", (e) => {
  isPressed = true;
  calculateMousePosition(e);
});
canvas.addEventListener("mouseup", () => {
  isPressed = false;
});
canvas.addEventListener("mousemove", (e) => {
  if (isPressed) {
    calculateMousePosition(e);
  }
});

// 터치 이벤트
canvas.addEventListener("touchstart", (e) => {
  isPressed = true;
  calculateMousePosition(e.touches[0]);
});
canvas.addEventListener("touchend", () => {
  isPressed = false;
});
canvas.addEventListener("touchmove", (e) => {
  if (isPressed) {
    calculateMousePosition(e.touches[0]);
  }
});

draw();

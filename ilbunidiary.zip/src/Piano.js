export class Piano {
  constructor(info) {
    this.x = info.x;
    this.y = info.y;
    this.z = info.z;

    this.visible = false;

    info.gltfLoader.load(
      info.modelSrc,
      (item) => {
        this.modelMesh = item.scene.children[0];
        this.modelMesh.castShadow = true;
        this.modelMesh.position.set(this.x, this.y, this.z);
        this.modelMesh.rotation.z = info.rotation.z;
        this.modelMesh.scale.set(info.scale.x, info.scale.y, info.scale.z);
        info.scene.add(this.modelMesh);
      },
      () => {},
      (err) => {
        console.log("🔥 에러발생 : ", err);
      }
    );
  }
}

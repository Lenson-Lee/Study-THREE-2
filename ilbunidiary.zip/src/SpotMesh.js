import * as THREE from "three";

/* 이벤트 스팟 포인터 ____________________________________________*/
export const CarSpot = new THREE.Mesh(
  new THREE.PlaneGeometry(1, 1),
  new THREE.MeshStandardMaterial({
    color: "yellow",
    transparent: true,
    opacity: 0.5,
  })
);
CarSpot.position.set(0, 0, -2);
CarSpot.rotation.x = -Math.PI / 2;
CarSpot.receiveShadow = true;

//
export const PianoSpot = new THREE.Mesh(
  new THREE.PlaneGeometry(3, 3),
  new THREE.MeshStandardMaterial({
    color: "yellow",
    transparent: true,
    opacity: 0.5,
  })
);
PianoSpot.position.set(20, 0.005, 0);
PianoSpot.rotation.x = -Math.PI / 2;
PianoSpot.receiveShadow = true;

//
export const CoinSpot = new THREE.Mesh(
  new THREE.PlaneGeometry(3, 3),
  new THREE.MeshStandardMaterial({
    color: "yellow",
    transparent: true,
    opacity: 0.5,
  })
);
// CoinSpot.position.set(4, 0, -2);
CoinSpot.position.set(20, 0.005, 5);
CoinSpot.rotation.x = -Math.PI / 2;
CoinSpot.receiveShadow = true;

//
